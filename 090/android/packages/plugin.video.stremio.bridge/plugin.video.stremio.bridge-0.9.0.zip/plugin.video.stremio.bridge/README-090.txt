CBR 0.9.0 clean-install baseline. Playback Python code is byte-for-byte from commit 05f482f.
Only platform addon.xml packaging and the previously used TVVoo default configuration differ.
No DaddyLive, IPTV-org or later caching code is included.
Use only the matching CBR 0.9.0 repository on a clean install to avoid updating to a newer branch.
