// EN: Disable MPTCP to reduce CVE-2026-98432 RCE risk: bug is in IPv4 TCP, but as of 2026-11-05 RCE is confirmed with MPTCP (see link below)
// RU: Отключаем MPTCP для снижения риска RCE по CVE-2026-98432: ошибка в IPv4 TCP, но на 2026-11-05 RCE подтверждён при MPTCP (см. ссылку ниже)
// reference: https://www.anthropic.com/research/discovering-vulnerabilities-with-claude section "5. Zero-click remote code execution in Linux"
//go:debug multipathtcp=0

package main

import (
	"context"
	"net"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"

	"server/torr/utils"

	"github.com/alexflint/go-arg"
	"github.com/fsnotify/fsnotify"
	"github.com/pkg/browser"

	"server"
	"server/docs"
	"server/log"
	"server/settings"
	"server/torr"
	"server/version"
)

type args struct {
	Port        string   `arg:"-p" help:"web server port (default 8090)"`
	IPs         []string `arg:"-i,--ip,separate" help:"web server bind addr (repeatable; default empty binds all interfaces)"`
	Ssl         bool     `help:"enables https"`
	SslPort     string   `help:"web server ssl port, If not set, will be set to default 8091 or taken from db(if stored previously). Accepted if --ssl enabled."`
	SslCert     string   `help:"path to ssl cert file. If not set, will be taken from db(if stored previously) or default self-signed certificate/key will be generated. Accepted if --ssl enabled."`
	SslKey      string   `help:"path to ssl key file. If not set, will be taken from db(if stored previously) or default self-signed certificate/key will be generated. Accepted if --ssl enabled."`
	Path        string   `arg:"-d" help:"database and config dir path"`
	LogPath     string   `arg:"-l" help:"server log file path"`
	WebLogPath  string   `arg:"-w" help:"web access log file path"`
	RDB         bool     `arg:"-r" help:"start in read-only DB mode"`
	HttpAuth    bool     `arg:"-a" help:"enable http auth on all requests"`
	DontKill    bool     `arg:"-k" help:"don't kill server on signal"`
	UI          bool     `arg:"-u" help:"open torrserver page in browser"`
	TorrentsDir string   `arg:"-t" help:"autoload torrents from dir"`
	TorrentAddr string   `help:"Torrent client address, like 127.0.0.1:1337 (default :PeersListenPort)"`
	PubIPv4     string   `arg:"-4" help:"set public IPv4 addr"`
	PubIPv6     string   `arg:"-6" help:"set public IPv6 addr"`
	SearchWA    bool     `arg:"-s" help:"search without auth"`
	MaxSize     string   `arg:"-m" help:"max allowed stream size (in Bytes)"`
	TGToken     string   `arg:"-T" help:"telegram bot token"`
	FusePath    string   `arg:"-f" help:"fuse mount path"`
	WebDAV      bool     `help:"web dav enable"`
	ProxyURL    string   `help:"proxy URL for BitTorrent traffic (http, socks4, socks5, socks5h), e.g. socks5://user:password@127.0.0.1:8080"`
	ProxyMode   string   `help:"proxy mode: tracker (only HTTP trackers, default), peers (only peer connections), or full (all traffic)"`
	ForceHTTPS  bool     `arg:"--force-https" help:"redirect all HTTP requests to HTTPS (requires --ssl)"`
	HTTPSOnly   bool     `arg:"--https-only" help:"with --ssl, don't open the plain HTTP port (--port): everything is served over HTTPS only. Players and TVs need a trusted certificate"`
	HTTPMedia   bool     `arg:"--http-media" help:"with --force-https, keep serving media URLs (/stream, /play, playlists) over plain HTTP for players and TVs that can't use HTTPS. Stream URLs and Basic auth credentials then travel unencrypted: use on trusted networks only"`
}

func (args) Version() string {
	return "TorrServer " + version.Version
}

var params args

func main() {
	runtime.GOMAXPROCS(runtime.NumCPU())

	arg.MustParse(&params)

	if params.Path == "" {
		params.Path, _ = os.Getwd()
	}

	if params.Port == "" {
		params.Port = settings.DefaultPort
	}

	settings.Path = params.Path
	settings.HttpAuth = params.HttpAuth
	log.Init(params.LogPath, params.WebLogPath)

	log.TLogln("=========== START ===========")
	log.TLogln("TorrServer", version.Version+",", runtime.Version()+",", "CPU Num:", runtime.NumCPU())
	if msg := configureCARoots(); msg != "" {
		log.TLogln(msg)
	}
	if params.HttpAuth {
		log.TLogln("Use HTTP Auth file", settings.Path+"/accs.db")
	}
	if params.RDB {
		log.TLogln("Running in Read-only DB mode!")
	}
	docs.SwaggerInfo.Version = version.Version

	// Simple Usage:
	dnsResolve()

	// Advanced Usage:
	// config := DNSConfig{
	//     PrimaryServers: []string{"1.1.1.1:53", "8.8.8.8:53"},
	//     Timeout:        3 * time.Second,
	// }
	// checker := NewDNSChecker(config)
	// // Perform DNS lookup with automatic fallback
	// addrs, err := checker.LookupHostWithFallback("themoviedb.org")
	// if err != nil {
	//     log.TLogln("DNS lookup failed:", err)
	// } else {
	// 	fmt.Println("DNS resolved:", addrs)
	// }

	Preconfig(params.DontKill)

	if params.UI {
		go func() {
			time.Sleep(time.Second)
			if params.Ssl {
				browser.OpenURL("https://127.0.0.1:" + params.SslPort)
			} else {
				browser.OpenURL("http://127.0.0.1:" + params.Port)
			}
		}()
	}

	if params.TorrentAddr != "" {
		settings.TorAddr = params.TorrentAddr
	}

	if params.PubIPv4 != "" {
		settings.PubIPv4 = params.PubIPv4
	}

	if params.PubIPv6 != "" {
		settings.PubIPv6 = params.PubIPv6
	}

	if params.TorrentsDir != "" {
		go watchTDir(params.TorrentsDir)
	}

	if params.MaxSize != "" {
		maxSize, err := strconv.ParseInt(params.MaxSize, 10, 64)
		if err == nil {
			settings.MaxSize = maxSize
		}
	}

	if params.ProxyURL != "" && params.ProxyMode == "" {
		params.ProxyMode = "tracker" // default
	}
	if params.ProxyMode != "" && params.ProxyMode != "tracker" && params.ProxyMode != "peers" && params.ProxyMode != "full" {
		log.TLogln("Invalid proxy mode, using default 'tracker'")
		params.ProxyMode = "tracker"
	}

	settings.Args = &settings.ExecArgs{
		Port:        params.Port,
		IPs:         params.IPs,
		Ssl:         params.Ssl,
		SslPort:     params.SslPort,
		SslCert:     params.SslCert,
		SslKey:      params.SslKey,
		Path:        params.Path,
		LogPath:     params.LogPath,
		WebLogPath:  params.WebLogPath,
		RDB:         params.RDB,
		HttpAuth:    params.HttpAuth,
		DontKill:    params.DontKill,
		UI:          params.UI,
		TorrentsDir: params.TorrentsDir,
		TorrentAddr: params.TorrentAddr,
		PubIPv4:     params.PubIPv4,
		PubIPv6:     params.PubIPv6,
		SearchWA:    params.SearchWA,
		MaxSize:     params.MaxSize,
		TGToken:     params.TGToken,
		FusePath:    params.FusePath,
		WebDAV:      params.WebDAV,
		ProxyURL:    params.ProxyURL,
		ProxyMode:   params.ProxyMode,
		ForceHTTPS:  params.ForceHTTPS,
		HTTPMedia:   params.HTTPMedia,
		HTTPSOnly:   params.HTTPSOnly,
	}

	if params.ProxyURL != "" {
		log.TLogln("Proxy configured from CLI:", params.ProxyURL, "mode:", settings.Args.ProxyMode)
	}

	if params.ForceHTTPS && !params.Ssl {
		log.TLogln("Error: --force-https requires --ssl")
		os.Exit(1)
	}
	if params.HTTPSOnly && !params.Ssl {
		log.TLogln("Error: --https-only requires --ssl")
		os.Exit(1)
	}
	if params.HTTPSOnly && params.HTTPMedia {
		log.TLogln("Error: --https-only and --http-media can't be combined (--https-only doesn't open the HTTP port)")
		os.Exit(1)
	}
	if params.HTTPMedia && !params.ForceHTTPS {
		log.TLogln("Error: --http-media requires --force-https (without it, media is already served over HTTP)")
		os.Exit(1)
	}

	if err := server.Start(); err != nil {
		log.TLogln(err)
		os.Exit(1)
	}
	log.TLogln(server.WaitServer())
	log.Close()
	time.Sleep(time.Second * 3)
	os.Exit(0)
}

func watchTDir(dir string) {
	path, err := filepath.Abs(dir) // Attempt to convert the provided dir path into an absolute (full) filesystem path.
	if err != nil {
		path = dir
	} // If an error occurs while obtaining the absolute path, the original relative path is used.

	watcher, err := fsnotify.NewWatcher() // Create a new filesystem watcher (event-based instead of polling).
	if err != nil {
		log.TLogln("Error creating watcher:", err)
		return
	}
	defer watcher.Close()

	err = watcher.Add(path) // Add target directory to watcher to receive filesystem events.
	if err != nil {
		log.TLogln("Error adding directory to watcher:", err)
		return
	}

	for { // Start of an infinite loop for continuous background monitoring using filesystem events.

		select {
		case event, ok := <-watcher.Events:
			if !ok {
				return
			}

			// Process only file creation or modification events
			if event.Op&(fsnotify.Create|fsnotify.Write) == 0 {
				continue
			}

			func() { // Open an anonymous function to isolate processing context per file.
				defer func() { // Deferred execution of a safety function that always runs at the end (even in case of panic).
					if r := recover(); r != nil { // Catch critical runtime errors (panic) during torrent processing.
						log.TLogln("Recovered from panic in watchTDir:", r) // Log recovered panic to prevent full service crash.
					}
				}()

				filename := event.Name                                     // Retrieves the full path of the file directly from the event generated by the watcher.
				if strings.ToLower(filepath.Ext(filename)) != ".torrent" { // Extract the file extension, convert it to lowercase, and check it. If it is not .torrent, the file is ignored.
					return // Ends execution of the anonymous function for the current file and moves to the next event.
				}

				sp, err := utils.OpenTorrentFile(filename) // Parse the torrent file: read Bencode structure and extract metadata.
				if err != nil {
					log.TLogln("Error parse file name:", err)
					return
				}

				tor, err := torr.AddTorrent(sp, "", "", "", "") // Add parsed torrent specification into active torrent engine.
				if err != nil {
					log.TLogln("Error parse torrent file:", err)
					return
				}

				if !tor.GotInfo() { // Check whether torrent metadata (info section) is available.
					log.TLogln("Error get info from torrent") // If metadata is missing, log error and skip processing.
					return
				}

				if tor.Title == "" { // If torrent has no custom title, assign default name from metadata.
					tor.Title = tor.Name()
				}

				// Long database operation is now safe
				torr.SaveTorrentToDB(tor) // Save torrent metadata into SQLite database.
				tor.Drop()                // Free RAM by removing torrent from active memory after processing.

				// Safely remove the original torrent file before writing to database.
				// This prevents reprocessing in case of repeated filesystem events.
				if err := os.Remove(filename); err != nil {
					log.TLogln("Error removing torrent file:", err)
				}
			}()

		case err, ok := <-watcher.Errors:
			if !ok {
				return
			}
			// Log filesystem watcher errors
			log.TLogln("Watcher error:", err)
		}
	}
}

///////////
/// DNS
///

// DNSConfig holds DNS resolver configuration
type DNSConfig struct {
	PrimaryServers  []string
	FallbackServers []string
	Timeout         time.Duration
	CacheDuration   time.Duration
}

// DefaultDNSConfig returns a sensible default configuration
func DefaultDNSConfig() DNSConfig {
	return DNSConfig{
		PrimaryServers: []string{
			"9.9.9.9:53", // Quad9 DNS
			"8.8.8.8:53", // Google DNS
			"1.1.1.1:53", // CloudFlare DNS
		},
		FallbackServers: []string{
			"208.67.222.222:53", // OpenDNS
			"64.6.64.6:53",      // Verisign
		},
		Timeout:       5 * time.Second,
		CacheDuration: 5 * time.Minute,
	}
}

// DNSChecker manages DNS resolution with fallback support
type DNSChecker struct {
	config         DNSConfig
	customResolver *net.Resolver
	cache          map[string][]string
	cacheTime      map[string]time.Time
	mu             sync.RWMutex
	useFallback    bool
}

// NewDNSChecker creates a new DNS checker instance
func NewDNSChecker(config DNSConfig) *DNSChecker {
	if len(config.PrimaryServers) == 0 {
		config = DefaultDNSConfig()
	}

	return &DNSChecker{
		config:    config,
		cache:     make(map[string][]string),
		cacheTime: make(map[string]time.Time),
	}
}

// CheckAndResolve performs DNS check and returns a resolver
func (d *DNSChecker) CheckAndResolve() *net.Resolver {
	// Test system DNS first
	if d.testSystemDNS() {
		log.TLogln("System DNS check passed")
		return net.DefaultResolver
	}
	log.TLogln("System DNS check failed, using custom resolver")
	d.initCustomResolver()
	return d.customResolver
}

// testSystemDNS checks if system DNS is working properly
func (d *DNSChecker) testSystemDNS() bool {
	ctx, cancel := context.WithTimeout(context.Background(), d.config.Timeout)
	defer cancel()

	addrs, err := net.DefaultResolver.LookupHost(ctx, "themoviedb.org")
	if err != nil {
		log.TLogln("DNS lookup error:", err)
		return false
	}

	if len(addrs) == 0 {
		log.TLogln("DNS lookup returned no addresses")
		return false
	}

	// Check for suspicious addresses (DNS hijacking/pollution)
	for _, addr := range addrs {
		if isSuspiciousAddress(addr) {
			log.TLogln("Suspicious DNS address detected:", addr)
			return false
		}
	}

	return true
}

// isSuspiciousAddress checks if an address indicates DNS issues
func isSuspiciousAddress(addr string) bool {
	suspiciousPrefixes := []string{
		"127.0.0.1", // Localhost
		"0.0.0.0",   // Invalid address
		"::1",       // IPv6 localhost
		// "10.",       // Private network
		"192.168.", // Private network
		"169.254.", // Link-local
	}

	for _, prefix := range suspiciousPrefixes {
		if strings.HasPrefix(addr, prefix) {
			return true
		}
	}

	return false
}

// initCustomResolver creates a custom resolver with fallback support
func (d *DNSChecker) initCustomResolver() {
	server := d.pickServer()
	if server == "" {
		log.TLogln("No DNS server from the list answered, keeping system resolver")
		d.customResolver = net.DefaultResolver
		return
	}
	log.TLogln("Using DNS server:", server)

	d.customResolver = &net.Resolver{
		PreferGo: true, // Use Go's DNS implementation
		Dial: func(ctx context.Context, network, address string) (net.Conn, error) {
			dialer := &net.Dialer{
				Timeout:   d.config.Timeout,
				KeepAlive: 30 * time.Second,
			}
			// UDP dial succeeds even when nobody answers, so the server
			// is chosen by a real reply in pickServer, not here
			return dialer.DialContext(ctx, network, server)
		},
	}

	d.useFallback = true
}

// LookupHostWithFallback performs DNS lookup with automatic fallback
func (d *DNSChecker) LookupHostWithFallback(host string) ([]string, error) {
	// Check cache first
	if addrs, ok := d.getFromCache(host); ok {
		return addrs, nil
	}

	// Use appropriate resolver
	var resolver *net.Resolver
	if d.useFallback && d.customResolver != nil {
		resolver = d.customResolver
	} else {
		resolver = net.DefaultResolver
	}

	// Perform lookup with timeout
	ctx, cancel := context.WithTimeout(context.Background(), d.config.Timeout)
	defer cancel()

	addrs, err := resolver.LookupHost(ctx, host)
	if err != nil {
		// If using system DNS fails, try custom resolver
		if !d.useFallback && d.customResolver != nil {
			log.TLogln("System DNS failed, trying custom resolver")
			addrs, err = d.customResolver.LookupHost(ctx, host)
		}
	}

	// Cache successful results
	if err == nil && len(addrs) > 0 {
		d.addToCache(host, addrs)
	}

	return addrs, err
}

// getFromCache retrieves DNS results from cache
func (d *DNSChecker) getFromCache(host string) ([]string, bool) {
	d.mu.RLock()
	defer d.mu.RUnlock()

	if addrs, ok := d.cache[host]; ok {
		if time.Since(d.cacheTime[host]) < d.config.CacheDuration {
			return addrs, true
		}
		// Expired, remove from cache
		delete(d.cache, host)
		delete(d.cacheTime, host)
	}

	return nil, false
}

// addToCache adds DNS results to cache
func (d *DNSChecker) addToCache(host string, addrs []string) {
	d.mu.Lock()
	defer d.mu.Unlock()

	d.cache[host] = addrs
	d.cacheTime[host] = time.Now()
}

// Simple usage function (backward compatible)
func dnsResolve() {
	checker := NewDNSChecker(DefaultDNSConfig())
	resolver := checker.CheckAndResolve()

	// Store the resolver for later use if needed
	net.DefaultResolver = resolver // Optional: replace global resolver

	if !checker.useFallback {
		return // system DNS has just resolved this name in the check
	}
	// Test the resolver
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	addrs, err := resolver.LookupHost(ctx, "themoviedb.org")
	if err != nil {
		log.TLogln("DNS resolution test failed:", err)
	} else {
		log.TLogln("DNS resolution successful, addresses:", addrs)
	}
}

// pickServer asks all servers at once and returns the first one that really
// answered with a non-suspicious address, or "" if none did within Timeout
func (d *DNSChecker) pickServer() string {
	servers := append(append([]string{}, d.config.PrimaryServers...), d.config.FallbackServers...)
	ctx, cancel := context.WithTimeout(context.Background(), d.config.Timeout)
	defer cancel()

	answered := make(chan string, len(servers))
	for _, server := range servers {
		go func(server string) {
			r := &net.Resolver{
				PreferGo: true,
				Dial: func(ctx context.Context, network, _ string) (net.Conn, error) {
					var dialer net.Dialer
					return dialer.DialContext(ctx, network, server)
				},
			}
			addrs, err := r.LookupHost(ctx, "themoviedb.org")
			if err != nil || len(addrs) == 0 {
				return
			}
			for _, addr := range addrs {
				if isSuspiciousAddress(addr) {
					return
				}
			}
			answered <- server
		}(server)
	}

	select {
	case server := <-answered:
		return server
	case <-ctx.Done():
		return ""
	}
}
