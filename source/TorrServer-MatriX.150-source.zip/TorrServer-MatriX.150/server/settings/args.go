package settings

type ExecArgs struct {
	Port        string
	IPs         []string
	Ssl         bool
	SslPort     string
	SslCert     string
	SslKey      string
	Path        string
	LogPath     string
	WebLogPath  string
	RDB         bool
	HttpAuth    bool
	DontKill    bool
	UI          bool
	TorrentsDir string
	TorrentAddr string
	PubIPv4     string
	PubIPv6     string
	SearchWA    bool
	MaxSize     string
	TGToken     string
	FusePath    string
	WebDAV      bool
	ProxyURL    string
	ProxyMode   string
	ForceHTTPS  bool
	HTTPMedia   bool
	HTTPSOnly   bool
}

var Args *ExecArgs
