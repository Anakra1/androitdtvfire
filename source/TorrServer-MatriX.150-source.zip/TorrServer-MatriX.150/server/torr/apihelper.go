package torr

import (
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"time"

	"github.com/anacrolix/torrent"
	"github.com/anacrolix/torrent/metainfo"

	"server/log"
	sets "server/settings"
	"server/torr/utils"
)

var bts *BTServer

// bts is read by request handlers without any synchronisation of their own, so it
// must be written exactly once. Connect calls this on every settings save with the
// same receiver, and the repeated assignment was reported by -race as a data race
// against every /stat request.
func InitApiHelper(bt *BTServer) {
	if bts == bt {
		return
	}
	bts = bt
}

func LoadTorrent(tor *Torrent) *Torrent {
	if tor.TorrentSpec == nil {
		return nil
	}
	tr, err := NewTorrent(tor.TorrentSpec, bts)
	if err != nil {
		return nil
	}
	if !tr.WaitInfo() {
		return nil
	}
	tr.Title = tor.Title
	tr.Poster = tor.Poster
	tr.Data = tor.Data
	return tr
}

func AddTorrent(spec *torrent.TorrentSpec, title, poster string, data string, category string) (*Torrent, error) {
	torr, err := NewTorrent(spec, bts)
	if err != nil {
		log.TLogln("error add torrent:", err)
		return nil, err
	}

	torDB := GetTorrentDB(spec.InfoHash)

	if torr.Title == "" {
		torr.Title = title
		if title == "" && torDB != nil {
			torr.Title = torDB.Title
		}
		if torr.Title == "" && torr.Torrent != nil && torr.Torrent.Info() != nil {
			torr.Title = torr.Info().Name
		}
	}

	if torr.Category == "" {
		torr.Category = category
		if torr.Category == "" && torDB != nil {
			torr.Category = torDB.Category
		}
	}

	if torr.Poster == "" {
		torr.Poster = poster
		if torr.Poster == "" && torDB != nil {
			torr.Poster = torDB.Poster
		}
	}

	if torr.Data == "" {
		torr.Data = data
		if torr.Data == "" && torDB != nil {
			torr.Data = torDB.Data
		}
	}

	return torr, nil
}

func SaveTorrentToDB(torr *Torrent) {
	log.TLogln("save to db:", torr.Hash())
	AddTorrentDB(torr)
}

// hashFromHex parses an info hash that came from an API request. Malformed
// input is reported instead of panicking like metainfo.NewHashFromHex.
func hashFromHex(hashHex string) (hash metainfo.Hash, ok bool) {
	return hash, hash.FromHexString(hashHex) == nil
}

func GetTorrent(hashHex string) *Torrent {
	hash, ok := hashFromHex(hashHex)
	if !ok {
		return nil
	}
	timeout := time.Second * time.Duration(sets.BTsets.TorrentDisconnectTimeout)
	if timeout > time.Minute {
		timeout = time.Minute
	}
	tor := bts.GetTorrent(hash)
	if tor != nil {
		tor.AddExpiredTime(timeout)
		return tor
	}

	tr := GetTorrentDB(hash)
	if tr != nil {
		tor = tr
		go func() {
			log.TLogln("New torrent", tor.Hash())
			tr, _ := NewTorrent(tor.TorrentSpec, bts)
			if tr != nil {
				tr.Title = tor.Title
				tr.Poster = tor.Poster
				tr.Data = tor.Data
				tr.Size = tor.Size
				tr.Timestamp = tor.Timestamp
				tr.Category = tor.Category
				tr.GotInfo()
			}
		}()
	}
	return tor
}

func SetTorrent(hashHex, title, poster, category string, data string) *Torrent {
	hash, ok := hashFromHex(hashHex)
	if !ok {
		return nil
	}
	torr := bts.GetTorrent(hash)
	torrDb := GetTorrentDB(hash)

	if title == "" && torr == nil && torrDb != nil {
		torr = GetTorrent(hashHex)
		torr.GotInfo()
		if torr.Torrent != nil && torr.Torrent.Info() != nil {
			title = torr.Info().Name
		}
	}

	if torr != nil {
		if title == "" && torr.Torrent != nil && torr.Torrent.Info() != nil {
			title = torr.Info().Name
		}
		torr.Title = title
		torr.Poster = poster
		torr.Category = category
		if data != "" {
			torr.Data = data
		}
	}
	// update torrent data in DB
	if torrDb != nil {
		torrDb.Title = title
		torrDb.Poster = poster
		torrDb.Category = category
		if data != "" {
			torrDb.Data = data
		}
		AddTorrentDB(torrDb)
	}
	if torr != nil {
		return torr
	} else {
		return torrDb
	}
}

func RemTorrent(hashHex string) {
	if sets.ReadOnly {
		log.TLogln("API RemTorrent: Read-only DB mode!", hashHex)
		return
	}
	hash, ok := hashFromHex(hashHex)
	if !ok {
		return
	}

	// Download the torrent before deleting it to get the "closed" status
	torr := bts.GetTorrent(hash)
	if torr == nil {
		// If the torrent isn't in memory, just delete it from the database and the files
		RemTorrentDB(hash)
		if sets.BTsets.UseDisk && hashHex != "" && hashHex != "/" {
			name := filepath.Join(sets.BTsets.TorrentsSavePath, hashHex)
			os.RemoveAll(name)
		}
		return
	}

	closedChan := torr.closed

	// Clear from memory
	if bts.RemoveTorrent(hash) {
		// Waiting for confirmation from the library via the closed channel
		select {
		case <-closedChan:
			// The library has confirmed the closure
			log.TLogln("Torrent closed by library:", hashHex)
		case <-time.After(5 * time.Second):
			log.TLogln("Warning: timeout waiting for torrent close:", hashHex)
		}

		// Now we can safely delete the files from the disk
		if sets.BTsets.UseDisk && hashHex != "" && hashHex != "/" {
			name := filepath.Join(sets.BTsets.TorrentsSavePath, hashHex)
			if _, err := os.Stat(name); err == nil {
				log.TLogln("Removing cache files for:", hashHex)
				os.RemoveAll(name)
			}
		}
	}

	// Delete from the database
	RemTorrentDB(hash)
}

func ListTorrent() []*Torrent {
	btlist := bts.ListTorrents()
	dblist := ListTorrentsDB()

	for hash, t := range dblist {
		if _, ok := btlist[hash]; !ok {
			btlist[hash] = t
		}
	}
	var ret []*Torrent

	for _, t := range btlist {
		ret = append(ret, t)
	}

	sort.Slice(ret, func(i, j int) bool {
		if ret[i].Timestamp != ret[j].Timestamp {
			return ret[i].Timestamp > ret[j].Timestamp
		} else {
			return ret[i].Title > ret[j].Title
		}
	})

	return ret
}

func DropTorrent(hashHex string) {
	hash, ok := hashFromHex(hashHex)
	if !ok {
		return
	}
	bts.RemoveTorrent(hash)
}

func SetSettings(set *sets.BTSets) {
	if sets.ReadOnly {
		log.TLogln("API SetSettings: Read-only DB mode!")
		return
	}
	sets.SetBTSets(set)
	utils.InvalidateTrackersCache()
	log.TLogln("drop all torrents")
	dropAllTorrent()
	time.Sleep(time.Second * 1)
	log.TLogln("disconect")
	bts.Disconnect()
	log.TLogln("connect")
	reconnect()
	time.Sleep(time.Second * 1)
	log.TLogln("end set settings")
}

// reconnect retries Connect after Disconnect. The uTP socket of the closed client
// closes lazily, only after its peer connections are gone, and until then
// PeersListenPort is busy: "listen udp4 :port: bind: address already in use".
// A failed Connect would leave bts.client nil until restart.
func reconnect() {
	var err error
	for i := 0; i < 30; i++ {
		if err = bts.Connect(); err == nil {
			if i > 0 {
				log.TLogln("connect ok, attempt", i+1)
			}
			return
		}
		if i == 0 {
			log.TLogln("connect error, retrying:", err)
		}
		time.Sleep(time.Second)
	}
	log.TLogln("connect failed:", err)
}

func SetDefSettings() {
	if sets.ReadOnly {
		log.TLogln("API SetDefSettings: Read-only DB mode!")
		return
	}
	sets.SetDefaultConfig()
	utils.InvalidateTrackersCache()
	log.TLogln("drop all torrents")
	dropAllTorrent()
	time.Sleep(time.Second * 1)
	log.TLogln("disconect")
	bts.Disconnect()
	log.TLogln("connect")
	reconnect()
	time.Sleep(time.Second * 1)
	log.TLogln("end set default settings")
}

func dropAllTorrent() {
	for _, torr := range bts.ListTorrents() {
		torr.drop()
		<-torr.closed
	}
}

func Shutdown() {
	if sets.Embedded {
		log.TLogln("Received shutdown (embedded)")
		if sets.EmbeddedStop != nil {
			sets.EmbeddedStop()
		}
		return
	}
	bts.Disconnect()
	sets.CloseDB()
	log.TLogln("Received shutdown. Quit")
	os.Exit(0)
}

// Disconnect sets bts.client to nil while a reconnect is in progress. Reading it
// without holding bt.mu races with that write and panics inside the torrent
// library, so readers enter bt.mu for the whole call: that also keeps Disconnect
// from closing the client underneath a reader, and a nil client is reported
// instead of dereferenced.
func WriteStatus(w io.Writer) {
	bts.mu.RLock()
	defer bts.mu.RUnlock()

	if bts.client == nil {
		_, _ = fmt.Fprintf(w, "Torrent client is not connected\n")
		return
	}
	bts.client.WriteStatus(w)
}

func Preload(torr *Torrent, index int) {
	cache := float32(sets.BTsets.CacheSize)
	preload := float32(sets.BTsets.PreloadCache)
	size := int64((cache / 100.0) * preload)
	if size <= 0 {
		return
	}
	if size > sets.BTsets.CacheSize {
		size = sets.BTsets.CacheSize
	}
	torr.Preload(index, size)
}
