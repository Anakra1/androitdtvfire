import axios from 'axios'
import { useEffect, useState, useMemo } from 'react'
import Button from '@material-ui/core/Button'
import InfoIcon from '@material-ui/icons/Info'
import ListItemIcon from '@material-ui/core/ListItemIcon'
import ListItemText from '@material-ui/core/ListItemText'
import { useTranslation } from 'react-i18next'
import { useMediaQuery } from '@material-ui/core'
import { echoHost } from 'utils/Hosts'
import { StyledDialog, StyledMenuButtonWrapper } from 'style/CustomMaterialUiStyles'
import { isStandaloneApp } from 'utils/Utils'
import useOnStandaloneAppOutsideClick from 'utils/useOnStandaloneAppOutsideClick'

import LinkComponent from './LinkComponent'
import { DialogWrapper, HeaderSection, ThanksSection, Section, FooterSection } from './style'

export default function AboutDialog() {
  const { t } = useTranslation()
  const [open, setOpen] = useState(false)
  const [torrServerVersion, setTorrServerVersion] = useState('')
  const fullScreen = useMediaQuery('@media (max-width:930px)')
  useEffect(() => {
    axios.get(echoHost()).then(({ data }) => setTorrServerVersion(data))
  }, [])

  const onClose = () => setOpen(false)
  const ref = useOnStandaloneAppOutsideClick(onClose)
  const basePath = useMemo(() => {
    if (typeof window !== 'undefined') {
      return window.location.pathname.split('/')[1] || ''
    }
    return ''
  }, [])

  return (
    <>
      <StyledMenuButtonWrapper button key='Settings' onClick={() => setOpen(true)}>
        {isStandaloneApp ? (
          <>
            <InfoIcon />
            <div>{t('Details')}</div>
          </>
        ) : (
          <>
            <ListItemIcon>
              <InfoIcon />
            </ListItemIcon>

            <ListItemText primary={t('About')} />
          </>
        )}
      </StyledMenuButtonWrapper>

      <StyledDialog
        open={open}
        onClose={onClose}
        aria-labelledby='form-dialog-title'
        fullScreen={fullScreen}
        maxWidth='xl'
        ref={ref}
      >
        <DialogWrapper>
          <HeaderSection>
            <div>{t('About')}</div>
            {torrServerVersion}
            <img src={`${basePath ? `/${basePath}` : ''}/icon.png`} alt='ts-icon' />
          </HeaderSection>

          <div style={{ overflow: 'auto' }}>
            <ThanksSection>{t('ThanksToEveryone')}</ThanksSection>

            <Section>
              <span>{t('Links')}</span>

              <div>
                <LinkComponent name={t('ProjectSource')} link='https://github.com/YouROK/TorrServer' />
                <LinkComponent name={t('Releases')} link='https://github.com/YouROK/TorrServer/releases' />
                <LinkComponent name={t('NasReleases')} link='https://github.com/vladlenas' />
                <LinkComponent name={t('ApiDocs')} link='swagger/index.html' />
              </div>
            </Section>

            <Section>
              <span>{t('SpecialThanks')}</span>

              <div>
                <LinkComponent name='Matt Joiner' link='https://github.com/anacrolix' />
                <LinkComponent name='Daniel Shleifman' link='https://github.com/dancheskus' />
                <LinkComponent name='nikk' link='https://github.com/tsynik' />
                <LinkComponent name='Pavel Pikta' link='https://github.com/pavelpikta' />
                <LinkComponent name='kolsys' link='https://github.com/kolsys' />
                <LinkComponent name='tw1cker' link='https://github.com/Nemiroff' />
                <LinkComponent name='Alexander' link='https://github.com/spawnlmg' />
                <LinkComponent name='damiva' link='https://github.com/damiva' />
                <LinkComponent name='Vladlenas' link='https://github.com/vladlenas' />
                <LinkComponent name='Anton Potekhin' link='https://github.com/Anton111111' />
                <LinkComponent name='FaintGhost' link='https://github.com/FaintGhost' />
                <LinkComponent name='TopperBG' link='https://github.com/TopperBG' />
                <LinkComponent name='Evgeni' link='https://github.com/lieranderl' />
                <LinkComponent name='cocool97' link='https://github.com/cocool97' />
                <LinkComponent name='shadeov' link='https://github.com/shadeov' />
                <LinkComponent name='Pavel' link='https://github.com/butaford' />
                <LinkComponent name='Alexey Filimonov' link='https://github.com/filimonic' />
                <LinkComponent name='Viacheslav Evseev' link='https://github.com/leporel' />
                <LinkComponent name='Vuzzy' link='https://github.com/VuzzyM' />
                <LinkComponent name='GriefNorth' link='https://github.com/GriefNorth' />
                <LinkComponent name='Nikita' link='https://github.com/nikita322' />
                <LinkComponent name='Dima Aratin' link='https://github.com/staners2' />
                <LinkComponent name='kostiavn' link='https://github.com/kostiavn' />
                <LinkComponent name='srgsf' link='https://github.com/srgsf' />
                <LinkComponent name='ngcores' link='https://github.com/ngcores' />
                <LinkComponent name='Kirill Pimenov' link='https://github.com/Cleste' />
                <LinkComponent name='Fikirsiz' link='https://github.com/Fikirsiz' />
                <LinkComponent name='kirill-782' link='https://github.com/kirill-782' />
                <LinkComponent name='Ilya Nikitenkov' link='https://github.com/nikitenich' />
                <LinkComponent name='Nicu' link='https://github.com/nicuvam' />
                <LinkComponent name='letov404-ai' link='https://github.com/tov404-ai' />
                <LinkComponent name='Renat Sharipov' link='https://github.com/SHAREN' />
                <LinkComponent name='Artem' link='https://github.com/DrachenClon22' />
                <LinkComponent name='Nicholas Velten' link='https://github.com/nfvelten' />
                <LinkComponent name='Struchkov Mark' link='https://github.com/uPagge' />
                <LinkComponent name='Alexander' link='https://github.com/LuckyRu' />
                <LinkComponent name='Mikhail' link='https://github.com/ManSio' />
                <LinkComponent name='Vladis.Shkarubov' link='https://github.com/vladikshkwok' />
                <LinkComponent name='Jay Hemnani' link='https://github.com/jayhemnani9910' />
                <LinkComponent name='Artem Draft' link='https://github.com/Drafteed' />
              </div>
            </Section>
          </div>

          <FooterSection>
            <Button onClick={onClose} color='primary' variant='contained'>
              {t('Close')}
            </Button>
          </FooterSection>
        </DialogWrapper>
      </StyledDialog>
    </>
  )
}
